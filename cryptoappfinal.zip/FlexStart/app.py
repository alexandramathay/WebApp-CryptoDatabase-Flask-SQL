# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)

db_name = 'final_df.db'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_name

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

# this variable, db, will be used for all SQLAlchemy commands
db = SQLAlchemy(app)

class df(db.Model):
    __tablename__ = 'data_table'
    index = db.Column(db.Integer, primary_key=True)
    news = db.Column(db.String)
    date = db.Column(db.Integer)
    coin = db.Column(db.String)
    relevance = db.Column(db.Integer)
    sentiment = db.Column(db.Integer)
    strength = db.Column(db.String)
    overall_score = db.Column(db.String)

@app.route("/")
def index():
    # get a list of unique values in the coin column
    coins = df.query.with_entities(df.coin).distinct()
    return render_template('index.html', coins=coins)

@app.route("/predictions/<coin>")
def predictions(coin):
    data = df.query.filter_by(coin=coin).order_by(df.index).all()
    return render_template('pred.html', data=data, coin=coin)

app.run(debug=True)